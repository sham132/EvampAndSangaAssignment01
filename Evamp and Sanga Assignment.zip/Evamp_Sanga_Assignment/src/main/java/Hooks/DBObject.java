package Hooks;

import java.util.Date;

public class DBObject {
	private String systemId;
	private String action;
	private String workerName;
	private String workerPersonalCode;
	private String workerGender;
	private int workerNumberOfKids;
	private String workerMotherMaidenName;
	private String workerGrandmotherMaidenName;
	private Date contractSignatureDate;
	private Date contractWorkStartDate;
	private String contractType;
	private Date contractEndDate;
	private String contractWorkerId;
	private double payAmount;
	private String payCurrency;
	private Date payEffectiveFrom;
	private Date payEffectiveTo;
	private double compensationAmount;
	private String compensationType;
	private String compensationCurrency;
	private Date compensationEffectiveFrom;
	private Date compensationEffectiveTo;

	// Add getters and setters for the fields
	// ...

	public String getSystemId() {
		return systemId;
	}

	public void setSystemId(String systemId) {
		this.systemId = systemId;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getWorkerName() {
		return workerName;
	}

	public void setWorkerName(String workerName) {
		this.workerName = workerName;
	}

	public String getWorkerPersonalCode() {
		return workerPersonalCode;
	}

	public void setWorkerPersonalCode(String workerPersonalCode) {
		this.workerPersonalCode = workerPersonalCode;
	}

	public String getWorkerGender() {
		return workerGender;
	}

	public void setWorkerGender(String workerGender) {
		this.workerGender = workerGender;
	}

	public int getWorkerNumberOfKids() {
		return workerNumberOfKids;
	}

	public void setWorkerNumberOfKids(int workerNumberOfKids) {
		this.workerNumberOfKids = workerNumberOfKids;
	}

	public String getWorkerMotherMaidenName() {
		return workerMotherMaidenName;
	}

	public void setWorkerMotherMaidenName(String workerMotherMaidenName) {
		this.workerMotherMaidenName = workerMotherMaidenName;
	}

	public String getWorkerGrandmotherMaidenName() {
		return workerGrandmotherMaidenName;
	}

	public void setWorkerGrandmotherMaidenName(String workerGrandmotherMaidenName) {
		this.workerGrandmotherMaidenName = workerGrandmotherMaidenName;
	}

	public Date getContractSignatureDate() {
		return contractSignatureDate;
	}

	public void setContractSignatureDate(Date contractSignatureDate) {
		this.contractSignatureDate = contractSignatureDate;
	}

	public Date getContractWorkStartDate() {
		return contractWorkStartDate;
	}

	public void setContractWorkStartDate(Date contractWorkStartDate) {
		this.contractWorkStartDate = contractWorkStartDate;
	}

	public String getContractType() {
		return contractType;
	}

	public void setContractType(String contractType) {
		this.contractType = contractType;
	}

	public Date getContractEndDate() {
		return contractEndDate;
	}

	public void setContractEndDate(Date contractEndDate) {
		this.contractEndDate = contractEndDate;
	}

	public String getContractWorkerId() {
		return contractWorkerId;
	}

	public void setContractWorkerId(String contractWorkerId) {
		this.contractWorkerId = contractWorkerId;
	}

	public double getPayAmount() {
		return payAmount;
	}

	public void setPayAmount(double payAmount) {
		this.payAmount = payAmount;
	}

	public String getPayCurrency() {
		return payCurrency;
	}

	public void setPayCurrency(String payCurrency) {
		this.payCurrency = payCurrency;
	}

	public Date getPayEffectiveFrom() {
		return payEffectiveFrom;
	}

	public void setPayEffectiveFrom(Date payEffectiveFrom) {
		this.payEffectiveFrom = payEffectiveFrom;
	}

	public Date getPayEffectiveTo() {
		return payEffectiveTo;
	}

	public void setPayEffectiveTo(Date payEffectiveTo) {
		this.payEffectiveTo = payEffectiveTo;
	}

	public double getCompensationAmount() {
		return compensationAmount;
	}

	public void setCompensationAmount(double compensationAmount) {
		this.compensationAmount = compensationAmount;
	}

	public String getCompensationType() {
		return compensationType;
	}

	public void setCompensationType(String compensationType) {
		this.compensationType = compensationType;
	}

	public String getCompensationCurrency() {
		return compensationCurrency;
	}

	public void setCompensationCurrency(String compensationCurrency) {
		this.compensationCurrency = compensationCurrency;
	}

	public Date getCompensationEffectiveFrom() {
		return compensationEffectiveFrom;
	}

	public void setCompensationEffectiveFrom(Date compensationEffectiveFrom) {
		this.compensationEffectiveFrom = compensationEffectiveFrom;
	}

	public Date getCompensationEffectiveTo() {
		return compensationEffectiveTo;
	}

	public void setCompensationEffectiveTo(Date compensationEffectiveTo) {
		this.compensationEffectiveTo = compensationEffectiveTo;
	}

	// You can also override the toString() method for debugging purposes
	@Override
	public String toString() {
		return "WorkerContract{" + "systemId='" + systemId + '\'' + ", action='" + action + '\'' + ", workerName='"
				+ workerName + '\'' +
				// Include other fields as needed
				'}';
	}
}
