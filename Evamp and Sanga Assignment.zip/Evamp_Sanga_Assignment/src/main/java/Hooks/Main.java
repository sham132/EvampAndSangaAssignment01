package Hooks;

import java.io.FileReader;
import java.util.Date;
import java.util.UUID;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.springframework.http.ResponseEntity;

import com.evamp.payloads.Request;

public class Main {

	static String workerPersonalCode = null;

	public static ResponseEntity<Request> main(CSVParser csvParser) {

		for (CSVRecord record : csvParser) {
			String systemId = record.get("SystemId");
			String action = record.get("ACTION");
			String workerName = record.get("worker_name");
			workerPersonalCode = record.get("worker_personalCode");
			String workerGender = record.get("worker_gender");
			String worker_numberOfKids = record.get("worker_numberOfKids");
			String worker_motherMaidenName = record.get("worker_motherMaidenName");
			String worker_grandmotherMaidenName = record.get("worker_grandmotherMaidenName");
			String contract_signatureDate = record.get("contract_signatureDate");
			String contract_workStartDate = record.get("contract_workStartDate");
			String contract_type = record.get("contract_type");
			String contract_endDate = record.get("contract_endDate");
			String contract_workerId = record.get("contract_workerId");
			String pay_amount = record.get("pay_amount");
			String pay_currency = record.get("pay_currency");
			String pay_effectiveFrom = record.get("pay_effectiveFrom");
			String pay_effectiveTo = record.get("pay_effectiveTo");
			String compensation_amount = record.get("compensation_amount");
			String compensation_type = record.get("compensation_type");
			String compensation_currency = record.get("compensation_currency");
			String compensation_effectiveFrom = record.get("compensation_effectiveFrom");
			String compensation_effectiveTo = record.get("compensation_effectiveTo");

			System.out.println(compensation_effectiveFrom);

			String contract_workStartDate_ = DateStandardization.standardizeDate(contract_workStartDate);
			String contract_endDate_ = DateStandardization.standardizeDate(contract_endDate);

			UUID uuid = null;
			if (systemId != null) {
				uuid = UUID.fromString(systemId.substring(0, 8) + "-" + systemId.substring(8, 12) + "-"
						+ systemId.substring(12, 16) + "-" + systemId.substring(16, 20) + "-" + systemId.substring(20));

			}

			if (workerPersonalCode == null || workerPersonalCode.equals("")) {

				Date firstWorkDay = new Date(); // Replace this with the actual first workday
				System.out.println(firstWorkDay);
				workerPersonalCode = EmployeeCode.generateEmployeeCode(firstWorkDay);

				System.out.println(workerPersonalCode);
			}

			if (uuid != null && workerName != null && workerPersonalCode != null && action != null
					&& pay_currency != null && contract_workStartDate != null && contract_endDate != null) {
				Request cbRequest = JsonParser.JsonParser(uuid.toString(), workerName, workerPersonalCode, action,
						pay_currency, contract_workStartDate_, contract_endDate_, workerGender);

				return ResponseEntity.ok(cbRequest);
			}

		}
		return null;

	}

}
