package Hooks;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.evamp.models.person;
import com.evamp.repos.person_repo;

import java.sql.PreparedStatement;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;

@Service
public class YourEntityService {

	private final person_repo repository;
	private final EntityManager entityManager;

	@Autowired
	public YourEntityService(person_repo repository, EntityManager entityManager) {
		this.repository = repository;
		this.entityManager = entityManager;
	}

	@Transactional
	public void dynamicallyInsertData(String tableName, Map<String, Object> columnValueMap) {
		
		System.out.println(tableName);
		// Create a new entity instance
		person entity = new person();

		// Set column values dynamically based on the map
		columnValueMap.forEach((columnName, value) -> {
			entityManager.unwrap(Session.class).doWork(connection -> {
				try (PreparedStatement ps = connection
						.prepareStatement("INSERT INTO " + tableName + " (" + columnName + ") VALUES (?)")) {
					ps.setObject(1, value);
					ps.executeUpdate();
				}
			});
		});

		repository.save(entity);
	}
}