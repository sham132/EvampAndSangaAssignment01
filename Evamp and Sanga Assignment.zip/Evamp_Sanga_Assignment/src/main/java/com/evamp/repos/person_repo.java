package com.evamp.repos;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.evamp.models.person;
import com.evamp.payloads.SelectData;

@Repository
public interface person_repo extends JpaRepository<person, Long> {

	boolean existsByEmployeeCode(String employeeCode);

	public static final String FIND_PROJECTS = "select * from person where employee_code=?1";

	@Query(value = FIND_PROJECTS, nativeQuery = true)

	public List<person> findByEmplpoyeeCode(String eCode);

	public static final String FIND_PROJECTS1 = "delete from person where employee_code=?1";

	@Query(value = FIND_PROJECTS1, nativeQuery = true)

	public List<person> deleteByEmplpoyeeCode(String eCode);

}