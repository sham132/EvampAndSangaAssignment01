package com.pmd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PmdApplicationTests {

	@Test
	void contextLoads() {
	}

}
