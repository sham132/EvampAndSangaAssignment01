package Hooks;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.evamp.payloads.PayComponent;
import com.evamp.payloads.PayloadElement;
import com.evamp.payloads.Request;

public class JsonParser {

	public static Request JsonParser(String uuid, String workerName, String workerPersonalCode, String action,
			String pay_currency, String contract_workStartDate, String contract_endDate, String gender) {

		Request cbRequest = new Request();

		cbRequest.setUuid(uuid.toString());
		cbRequest.setFname(workerName);
		cbRequest.setErrors(Arrays.asList("This is a sample error text!"));

		List<PayloadElement> payloadElements = new ArrayList<>();

		List<PayComponent> payComponent = new ArrayList<>();
		PayloadElement payloadElement = new PayloadElement();

		payloadElement.setEmployeeCode(workerPersonalCode);
		payloadElement.setAction(action);

		PayComponent pc = new PayComponent();

		pc.setAmount(1000);
		pc.setCurrency(pay_currency);
		pc.setStartDate(contract_workStartDate);
		pc.setEndDate(contract_endDate);

		payComponent.add(pc);

		payloadElement.setPayComponents(payComponent);

		payloadElements.add(payloadElement);

		Map<String, Object> data = new HashMap<>();

	

		data.put("person.full_name", workerName);
		data.put("person.gender", gender);
		data.put("person.hire_date", contract_workStartDate);
		data.put("person.termination_date", contract_endDate);

//		data.put("salary_component.person_id", "FGGCrjhh54");
//		data.put("salary_component.currency", "USD");

		payloadElement.setData(data);

		cbRequest.setPayload(payloadElements);

		return cbRequest;
	}
}
