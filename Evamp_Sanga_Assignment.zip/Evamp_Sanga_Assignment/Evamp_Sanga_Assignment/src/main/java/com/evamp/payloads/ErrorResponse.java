package com.evamp.payloads;

public class ErrorResponse {

	private String errorCode;
	private String error;
	

	public ErrorResponse(String errorCode,String error) {
		super();
		this.setError(error);
		this.errorCode = errorCode;
	}



	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}



	public String getError() {
		return error;
	}



	public void setError(String error) {
		this.error = error;
	}

}
