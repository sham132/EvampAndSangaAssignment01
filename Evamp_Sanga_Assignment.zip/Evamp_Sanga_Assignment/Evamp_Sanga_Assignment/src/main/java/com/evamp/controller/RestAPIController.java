
package com.evamp.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.util.List;
import java.util.Map;

import javax.transaction.Transactional;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.evamp.payloads.ErrorResponse;
import com.evamp.payloads.PayloadElement;
import com.evamp.payloads.Request;
import com.evamp.repos.person_repo;
import com.evamp.repos.salary_component_repo;

import Hooks.InsertHook;
import Hooks.Main;

@org.springframework.web.bind.annotation.RestController
@RequestMapping("/api/v1/rest/csv/")
public class RestAPIController {

	@Autowired
	person_repo prepo;

	@Autowired
	salary_component_repo srepo;

	private static final Logger log = LogManager.getLogger(RestAPIController.class);

	@PostMapping("task1/upload")
	public ResponseEntity<Object> EvampandSangaTask1(@RequestParam(name = "file", required = false) MultipartFile file)
			throws IOException {

		if (file == null || file.isEmpty()) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("file not found.");
		}

		try (BufferedReader reader = new BufferedReader(new InputStreamReader(file.getInputStream()));
				CSVParser csvParser = new CSVParser(reader, CSVFormat.DEFAULT.withHeader())) {

			ResponseEntity<Request> result = Main.main(csvParser);

			return ResponseEntity.ok(result.getBody());
		} catch (IOException e) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Invalid file upload request.");

		}

	}

	@PostMapping("task2/upload")
	@Transactional
	public ResponseEntity<Object> EvampandSangaTask2(@RequestParam(name = "file", required = false) MultipartFile file)
			throws IOException, ParseException {

		if (file == null || file.isEmpty()) {
			return new ResponseEntity<Object>(new ErrorResponse("03", "File not found."), HttpStatus.BAD_REQUEST);

		}

		try (BufferedReader reader = new BufferedReader(new InputStreamReader(file.getInputStream()));
				CSVParser csvParser = new CSVParser(reader, CSVFormat.DEFAULT.withHeader())) {

			ResponseEntity<Request> result = Main.main(csvParser);
			
			if (result != null) {
				List<PayloadElement> data = result.getBody().getPayload();

				Map<String, String> data1 = (Map<String, String>) data.get(0).getData();

				
				InsertHook.Insert(data1, result, prepo, srepo);
				
				
				

				return ResponseEntity.ok(result.getBody());
			} else {
				return new ResponseEntity<Object>(new ErrorResponse("01", "No Action Found."), HttpStatus.BAD_REQUEST);

			}

		} catch (IOException e) {
			return new ResponseEntity<Object>(new ErrorResponse("02", "Invalid file upload request."),
					HttpStatus.BAD_REQUEST);

		}

	}

}
