package com.evamp.payloads;

public class SecondEntity {
	private String third_field;

	public String getThird_field() {
		return third_field;
	}

	public void setThird_field(String third_field) {
		this.third_field = third_field;
	}
}
